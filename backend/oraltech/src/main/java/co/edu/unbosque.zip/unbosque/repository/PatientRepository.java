package co.edu.unbosque.repository;

import co.edu.unbosque.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PatientRepository extends JpaRepository<Patient, Long> {
    Optional<Patient> findByIdNumber(String idNumber);

    boolean existsByIdNumber(String idNumber);
}
